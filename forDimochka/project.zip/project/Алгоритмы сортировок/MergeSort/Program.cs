﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        Console.Write("Введите количество элементов в массиве: ");
        int n = Convert.ToInt32(Console.ReadLine());

        int[] arr = new int[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write("Введите элемент {0}: ", i + 1);
            arr[i] = Convert.ToInt32(Console.ReadLine());
        }

        MergeSort.Sort(arr);

        Console.WriteLine("Отсортированный массив:");
        foreach (int element in arr)
            Console.Write(element + " ");
    }
}

public class MergeSort
{
    public static void Sort(int[] array)
    {
        int n = array.Length;

        if (n < 2)
            return;

        int mid = n / 2;
        int[] left = new int[mid];
        int[] right = new int[n - mid];

        for (int i = 0; i < mid; i++)
            left[i] = array[i];

        for (int i = mid; i < n; i++)
            right[i - mid] = array[i];

        Sort(left);
        Sort(right);
        Merge(array, left, right);
    }

    private static void Merge(int[] array, int[] left, int[] right)
    {
        int leftLength = left.Length;
        int rightLength = right.Length;
        int i = 0, j = 0, k = 0;

        while (i < leftLength && j < rightLength)
        {
            if (left[i] <= right[j])
                array[k++] = left[i++];
            else
                array[k++] = right[j++];
        }

        while (i < leftLength)
            array[k++] = left[i++];

        while (j < rightLength)
            array[k++] = right[j++];
    }
}